from django.urls import path, include
from .views import *

urlpatterns = [
    path('api/request-example/', RequestExampleView.as_view()),
    path('api/books-generic/', BookListCreateGenericView.as_view()),
    path('api/books-auth/', BookAuthOnlyView.as_view()),

]
