from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics, viewsets, filters, permissions, throttling, pagination
from rest_framework.authentication import SessionAuthentication
from .models import Book
from .serializers import BookSerializer

class RequestExampleView(APIView):
    def get(self, request):
        return Response({"message": "GET request successful"})

    def post(self, request):
        return Response({"received_data": request.data})


class BookListCreateGenericView(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer


from rest_framework import viewsets

class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer


class BookAuthOnlyView(generics.ListAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    permission_classes = [permissions.IsAuthenticated]


