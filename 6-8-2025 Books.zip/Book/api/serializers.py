from rest_framework import serializers
from .models import Book

class BookSerializer(serializers.ModelSerializer):
    def validate_title(self, value):
        if "bad" in value.lower():
            raise serializers.ValidationError("Title contains invalid word.")
        return value

    class Meta:
        model = Book
        fields = '__all__'
