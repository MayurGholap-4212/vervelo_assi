import requests

endpoint='http://127.0.0.1:8000/api/books-generic/'

data={'title':'rfg',
      'author':'dfg',
      'published':'2025-01-02'
      }

get_response=requests.post(endpoint,data)
get_responses=requests.get(endpoint,data)

print(get_response.text)
print(get_responses.text)